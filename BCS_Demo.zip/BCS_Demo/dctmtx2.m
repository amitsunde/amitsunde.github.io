function out=dctmtx2(n)
d=[];i=1; %n=16; %size of 2d dct basis function here 16 x 16
for v=1:n
    for u=1:n
        p=zeros(n);
        if (u-1)==0
            c(u)=sqrt(1/n);
        else
            c(u)=sqrt(2/n);
        end
         if (v-1)==0
            c(v)=sqrt(1/n);
        else
            c(v)=sqrt(2/n);
         end
         
         for x=1:n
            for y=1:n
                p(x,y)=c(u)*c(v)*cos(pi*(u-1)*(2*(x-1)+1)/(2*n))*cos(pi*(v-1)*(2*(y-1)+1)/(2*n));
            end
        end
        d(:,:,i)=p;
        i=i+1;
    end
end
b=zeros(n*n);
for ik=1:n*n
tmp=d(:,:,ik);
b(ik,:)=tmp(:)';
end
out=b;
end