clc; clear all; close all;

im = imread('goldhill.pgm');

[m n p] = size(im);

if p == 3
    im = rgb2gray(im);
end

im = double(im);

block_size = 32;

im_col = im2col(im,[block_size block_size],'distinct'); 

subrate = 0.4; 
M = round(subrate * block_size * block_size); 

Phi = orth(randn(block_size * block_size, block_size * block_size));
Phi = Phi(1:M,:);

y = Phi * im_col; 

reconstructed_image = BCS_SPL_DDWT_Decoder(y, Phi, m, n, 5);

initial_condition = im2col(reconstructed_image, [block_size block_size], 'distinct');

reconstructed_image_final = individual_focuss(y, Phi, block_size, m, n, initial_condition);

p = PSNR(im, reconstructed_image_final)
s = ssim(im, reconstructed_image_final)